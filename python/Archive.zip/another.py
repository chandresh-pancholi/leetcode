import time
def timeTemp():
    localtime = time.localtime(time.time())
    print localtime