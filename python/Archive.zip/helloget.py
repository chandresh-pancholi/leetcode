import another
def foo(event, context):
    another.timeTemp()
    return "hello world"