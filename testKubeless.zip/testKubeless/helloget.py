def foo(event, context):
    return "hello world"
